<!DOCTYPE html>

<html class="no-js">
    <head>
        <meta charset="utf-8">
		<!-- Site Title -->
        <title> ultra-job </title>
        <meta name="description" content="ultra-job">
        <meta name="viewport" content="width=device-width">
		<!-- Load Css -->
		<link rel="stylesheet" type="text/css" href="Link/css/cssloader.css" />
		<!-- Main Style -->
		<link rel="stylesheet" type="text/css" href="main.css" />
	
</head>
<body>
<nav>
	<!-- ==================== Navbar ==================== -->
	<div class="navbar navbar-fixed-top">
		<div class="navbar-inner from-top">
		<div class="container">
			<button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
		<a class="brand" href="index.php"><img src="Link/images/Logo.jpg"  style="height:65px;"/> </a>
			<div class="nav-collapse collapse">
				<ul class="nav pull-right">
					<li class="dropdown"><a href="index.html">Home</a></li>
					<li class="dropdown"><a href="about.html">About Us</a>
						<!-- <ul class="dropdown-menu">
							<li class="active"><a href="#">Page 1</a></li>
							<li><a href="#">Page 2</a></li>
							<li><a href="#">Page 3</a></li>
							<li><a href="#">Page 4</a></li>
						</ul> -->
					</li>
					<li class="dropdown"><a href="services.html">Services</a></li>
					<li><a href="contact.html">Contact</a></li>
					<!-- Search Form -->		
					<li class="search-container">
						<div id="search-form">
							<form method="get" action="#">
								<input type="text" class="search-text-box" />
							</form>
						</div>
					</li>
				</ul>
			</div>
		</div>
		</div>
		<div class="top-soc hidden-phone">
			<div class="container">
				<div class="row">
					<div class="span6 from-right">
					<ul class="address">
						<li><span><i class="fa fa-phone"></i></span>+62 123-456-7890</li>
						<li><span><i class="fa fa-envelope"></i></span>support@email.com</li>
					</ul>
					</div>
					<div class="span6 from-left">
						<ul class="social text-right">
							<li><a class="fa fa-facebook" href="#" target="_blank"></a></li>
							<li><a class="fa fa-twitter" href="#" target="_blank"></a></li>
							<li><a class="fa fa-google-plus" href="#" target="_blank"></a></li>
							<li><a class="fa fa-linkedin" href="#" target="_blank"></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- ==================== /Navbar ==================== -->
</nav>	