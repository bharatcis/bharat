<!-- <div class="purchase text-center">
		<div class="container">
			<h3 class="fade-in">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt</h3>
		</div>
	</div> -->
	
	<!-- ==================== Footer Top ==================== -->
		<div class="subfooter fade-in">
		<div class="container">
			<div class="row">
                <div class="span6">
                    <p>© Copyright 2016 - <a href="javascript:void(0);" target="_blank"> ultra-job </a></p>                    
                </div>
			<!-- 	<div class="span6">
                    <nav>
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li><a href="about.html">About</a></li>							
							<li><a href="services.html">Services</a></li>
							<li><a href="contact.html">Contact</a></li>
                        </ul>
                     </nav>
                </div> -->
            </div>
		</div>
	</div>
	</div>
<footer>
<script type="text/javascript" src="Link/js/jquery-1.10.1.min.js"></script>
<script type="text/javascript" src="Link/js/jquery-migrate-1.2.1.min.js"></script>
<!-- Bootstrap -->
<script type="text/javascript" src="Link/js/bootstrap.min.js"></script>
<script type="text/javascript" src="Link/js/jquery.easing.min.js"></script>
<!-- Modernizr -->
<script type="text/javascript" src="Link/js/modernizr.custom.js"></script>
<!-- prettyPhoto -->
<script type="text/javascript" src="Link/js/jquery.prettyPhoto.js"></script>
<!-- Parallax -->
<script type="text/javascript" src="Link/js/jquery.parallax-1.1.3.js"></script>
<!-- slider camera -->
<script type="text/javascript" src="Link/js/camera/jquery.mobile.customized.min.js"></script>
<script type="text/javascript" src="Link/js/camera/camera.js"></script>
<!-- Flexslider -->
<script type="text/javascript" src="Link/js/flexslider/jquery.flexslider.js"></script>
<!-- gmap -->
<script type="text/javascript" src="Link/js/gmap/jquery.gmap.min.js"></script>
<script type="text/javascript" src="Link/js/gmap/map.js"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<!-- Navbar -->
<script type="text/javascript" src="Link/js/navbar/classie.js"></script>
<script type="text/javascript" src="Link/js/navbar/cbpAnimatedHeader.js"></script>
<!-- jquery-ui -->
<script type="text/javascript" src="Link/js/jquery-ui.js"></script>
<!-- appear -->
<script type="text/javascript" src="Link/js/appear.js"></script>
<!-- Main Script -->
<script type="text/javascript" src="Link/js/main.js"></script>
</footer>
</body>
</html>