<?php  include('header.php');?>

<section id="sub-nav">
	<div class="container">	
			<div class="span">
				<h4 class="from-top"> Contact Us </h4>
			
			</div>		
	</div>
</section>

	
<section id="contact">
	<div class="container fade-in">
		
		<div class="row-fluid">
			<div class="span8">	
			<h3>Find a rewarding job for a European company.</h3>
			<p>ULTRA-JOB is a recruitment center in Abidjan and specialized in outsourced work. 
			  We mainly work with European companies.
			</p>
			
			<h3> Contact Us</h3>
				<form id="form" class="contact" action="contact.php" method="post" name="contactform">
				<textarea name="msg" placeholder="Insert your message" class="span12"></textarea>
				<input type="text" name="subject" value="" size="40" placeholder="Subject" class="span12">
				<div class="row-fluid">
				<div class="span5">
					<input type="text" name="name" value="" size="40" placeholder="Your Name" class="span12">
				</div>
				<div class="span5">
					<input type="email" name="email" value="" size="40" placeholder="Your Email" class="span12">
				</div>
				<div class="span2">
					<button class="btn btn-block" id="submit" type="submit" name="submit">Submit</button>
				</div>
				</div>
				</form>
			</div>
			<div class="span4">
				<h3> Find a rewarding job for a European company </h3>
				<p>ULTRA-JOB is a recruitment center in Abidjan and specialized in outsourced work. 
			  We mainly work with European companies.</p>
				<ul class="contact">
					<li><span><i class="fa fa-rocket"></i></span>ULTRA-JOB </li>
					<li><span><i class="fa fa-phone"></i></span>+225 87 86 39 34</li>
					<li><span><i class="fa fa-mobile"></i></span>+225 87 86 39 34</li>
					<li><span><i class="fa fa-envelope"></i></span>contact@ultra-job.com</li>
					<li><span><i class="fa fa-globe"></i></span>ultra-job.com </li>
				</ul>
			</div>
		</div>
	</div>
</section>
<?php include('footer.php'); ?>